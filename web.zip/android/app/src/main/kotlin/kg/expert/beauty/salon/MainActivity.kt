package kg.expert.beauty.salon

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
